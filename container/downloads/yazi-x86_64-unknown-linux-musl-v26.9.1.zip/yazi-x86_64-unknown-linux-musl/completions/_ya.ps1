
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'ya' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'ya'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'ya' {
            [CompletionResult]::new('-V', '-V ', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('--version', '--version', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('emit', 'emit', [CompletionResultType]::ParameterValue, 'Emit an action to be executed by the current instance')
            [CompletionResult]::new('emit-to', 'emit-to', [CompletionResultType]::ParameterValue, 'Emit an action to be executed by the specified instance')
            [CompletionResult]::new('exec', 'exec', [CompletionResultType]::ParameterValue, 'Execute an action on the current instance and print its result')
            [CompletionResult]::new('pkg', 'pkg', [CompletionResultType]::ParameterValue, 'Manage packages')
            [CompletionResult]::new('pub', 'pub', [CompletionResultType]::ParameterValue, 'Publish a message to the current instance')
            [CompletionResult]::new('pub-to', 'pub-to', [CompletionResultType]::ParameterValue, 'Publish a message to the specified instance')
            [CompletionResult]::new('sub', 'sub', [CompletionResultType]::ParameterValue, 'Subscribe to messages from all remote instances')
            [CompletionResult]::new('cache', 'cache', [CompletionResultType]::ParameterValue, 'Manage the cache')
            [CompletionResult]::new('env', 'env', [CompletionResultType]::ParameterValue, 'Print environment and configuration information')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;emit' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;emit-to' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;exec' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add packages')
            [CompletionResult]::new('delete', 'delete', [CompletionResultType]::ParameterValue, 'Delete packages')
            [CompletionResult]::new('install', 'install', [CompletionResultType]::ParameterValue, 'Install all packages')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List all packages')
            [CompletionResult]::new('upgrade', 'upgrade', [CompletionResultType]::ParameterValue, 'Upgrade all packages')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;pkg;add' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg;delete' {
            [CompletionResult]::new('--discard', '--discard', [CompletionResultType]::ParameterName, 'Discard local changes made to packages while deleting')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg;install' {
            [CompletionResult]::new('--discard', '--discard', [CompletionResultType]::ParameterName, 'Discard local changes made to packages while installing')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg;list' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg;upgrade' {
            [CompletionResult]::new('--discard', '--discard', [CompletionResultType]::ParameterName, 'Discard local changes made to packages while upgrading')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pkg;help' {
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add packages')
            [CompletionResult]::new('delete', 'delete', [CompletionResultType]::ParameterValue, 'Delete packages')
            [CompletionResult]::new('install', 'install', [CompletionResultType]::ParameterValue, 'Install all packages')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List all packages')
            [CompletionResult]::new('upgrade', 'upgrade', [CompletionResultType]::ParameterValue, 'Upgrade all packages')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;pkg;help;add' {
            break
        }
        'ya;pkg;help;delete' {
            break
        }
        'ya;pkg;help;install' {
            break
        }
        'ya;pkg;help;list' {
            break
        }
        'ya;pkg;help;upgrade' {
            break
        }
        'ya;pkg;help;help' {
            break
        }
        'ya;pub' {
            [CompletionResult]::new('--str', '--str', [CompletionResultType]::ParameterName, 'Send the message with a string body')
            [CompletionResult]::new('--json', '--json', [CompletionResultType]::ParameterName, 'Send the message with a JSON body')
            [CompletionResult]::new('--list', '--list', [CompletionResultType]::ParameterName, 'Send the message as a list of strings')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;pub-to' {
            [CompletionResult]::new('--str', '--str', [CompletionResultType]::ParameterName, 'Send the message with a string body')
            [CompletionResult]::new('--json', '--json', [CompletionResultType]::ParameterName, 'Send the message with a JSON body')
            [CompletionResult]::new('--list', '--list', [CompletionResultType]::ParameterName, 'Send the message as a list of strings')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;sub' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;cache' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('clear', 'clear', [CompletionResultType]::ParameterValue, 'Clear the cache directory')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;cache;clear' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;cache;help' {
            [CompletionResult]::new('clear', 'clear', [CompletionResultType]::ParameterValue, 'Clear the cache directory')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;cache;help;clear' {
            break
        }
        'ya;cache;help;help' {
            break
        }
        'ya;env' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'ya;help' {
            [CompletionResult]::new('emit', 'emit', [CompletionResultType]::ParameterValue, 'Emit an action to be executed by the current instance')
            [CompletionResult]::new('emit-to', 'emit-to', [CompletionResultType]::ParameterValue, 'Emit an action to be executed by the specified instance')
            [CompletionResult]::new('exec', 'exec', [CompletionResultType]::ParameterValue, 'Execute an action on the current instance and print its result')
            [CompletionResult]::new('pkg', 'pkg', [CompletionResultType]::ParameterValue, 'Manage packages')
            [CompletionResult]::new('pub', 'pub', [CompletionResultType]::ParameterValue, 'Publish a message to the current instance')
            [CompletionResult]::new('pub-to', 'pub-to', [CompletionResultType]::ParameterValue, 'Publish a message to the specified instance')
            [CompletionResult]::new('sub', 'sub', [CompletionResultType]::ParameterValue, 'Subscribe to messages from all remote instances')
            [CompletionResult]::new('cache', 'cache', [CompletionResultType]::ParameterValue, 'Manage the cache')
            [CompletionResult]::new('env', 'env', [CompletionResultType]::ParameterValue, 'Print environment and configuration information')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'ya;help;emit' {
            break
        }
        'ya;help;emit-to' {
            break
        }
        'ya;help;exec' {
            break
        }
        'ya;help;pkg' {
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add packages')
            [CompletionResult]::new('delete', 'delete', [CompletionResultType]::ParameterValue, 'Delete packages')
            [CompletionResult]::new('install', 'install', [CompletionResultType]::ParameterValue, 'Install all packages')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List all packages')
            [CompletionResult]::new('upgrade', 'upgrade', [CompletionResultType]::ParameterValue, 'Upgrade all packages')
            break
        }
        'ya;help;pkg;add' {
            break
        }
        'ya;help;pkg;delete' {
            break
        }
        'ya;help;pkg;install' {
            break
        }
        'ya;help;pkg;list' {
            break
        }
        'ya;help;pkg;upgrade' {
            break
        }
        'ya;help;pub' {
            break
        }
        'ya;help;pub-to' {
            break
        }
        'ya;help;sub' {
            break
        }
        'ya;help;cache' {
            [CompletionResult]::new('clear', 'clear', [CompletionResultType]::ParameterValue, 'Clear the cache directory')
            break
        }
        'ya;help;cache;clear' {
            break
        }
        'ya;help;env' {
            break
        }
        'ya;help;help' {
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
