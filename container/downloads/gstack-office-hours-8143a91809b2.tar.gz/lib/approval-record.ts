/**
 * approval-record — the per-thread approval record gstack keeps for Capy
 * Captains (capy/skill/gstack/captain.md): one row per answer, with the date,
 * what was asked, the person's exact words, who said them, what the answer
 * covers, what is still pending and the outcome. bin/gstack-approvals is the
 * CLI; /ship pastes `render` into the PR body as `## Approvals` and a crew
 * thread pastes it into its report.
 *
 * The record is display and audit only. It is not an approval citation
 * (lib/approval-citations.ts stays the one enforced mechanism): every cell is
 * escaped so the rendered table cannot be parsed as an `Approved by ...`
 * citation, a mention, an image or hidden HTML.
 *
 * Storage: `<state root>/projects/<slug>/approvals/<branch key>.jsonl`, the
 * branch key being a readable prefix plus a hash of the exact ref (no two
 * branches share a file, and the key is always one contained path segment).
 * On Capy (GSTACK_CAPY=1) the state root is thrown away with the machine, so
 * every write is mirrored: to GSTACK_APPROVALS_DIR when set, else to the
 * directory the Captain named by creating `approvals/` in its drive
 * (`~/.capy/drive/captain-<name>/approvals/<slug>/<branch key>.jsonl`, which every
 * crew thread can read), else to the private project-user Drive folder
 * (`<drive>/approvals/<slug>/<branch key>.jsonl`). GSTACK_APPROVALS_MIRROR=0
 * turns the mirror off. Reads take the union of both. A fixture (bun test, or a
 * state root or repository in the temp directory) only mirrors inside the temp
 * directory, links resolved. Every field passes the secret scanner before
 * anything is written.
 */
import { createHash } from 'node:crypto';
import { spawnSync } from './spawn-sync';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { capyDriveFolder } from './autoplan-checkpoint';
import { reviewedPlan } from './captain-brief';
import { slugFromEnvironment } from './bin-context';
import { firstTitle } from './markdown-sections';
import { scan, type Finding } from './redact-engine';
import type { ResultCodeName } from './result-codes';
import { resolveStateRoot } from './state-root';
import { isSecurityFinding, REDACTED_FINDING, REDACTED_REASON, REDACTED_WORDS } from './security-findings';

export const OUTCOMES = ['approved', 'rejected', 'pending', 'standing'] as const;
export type Outcome = typeof OUTCOMES[number];
export const CAPS = { ask: 300, words: 2000, scope: 300, pending: 300, by: 120, source: 200 } as const;

export interface ApprovalRow {
  schema_version: 1; id: string; date: string; ask: string; words: string; by: string;
  scope: string; pending: string; outcome: Outcome; source: string; branch: string; recorded_at: string;
  /** Set by import when the gate was answered in an agent's own words (--words-by); lib/plan-record.ts refuses such a row as a plan approval. */
  words_by?: string;
  /** Set by gstack-approvals gate only: lib/gate-dispositions.ts's checksum over the row's canonical fields (catches an edit; not authentication). */
  digest?: string;
}
export type MirrorSource = 'GSTACK_APPROVALS_DIR' | 'captain drive' | 'project-user drive';
/** `mirror` is written and read; `read_also` are the other mirror roots' copies, read so a row mirrored under an earlier rule stays visible. */
/** `mirror_refused` names a mirror a fixture would have written outside its temp root; the write then fails and nothing reaches that Drive. */
export interface StoreLocation { file: string; mirror?: string; mirror_source?: MirrorSource; read_also?: string[]; mirror_refused?: string; branch: string; slug: string; ephemeral: boolean }
export interface RecordError { code: ResultCodeName; message: string }
export type Env = NodeJS.ProcessEnv;

const git = (cwd: string, args: string[]) => spawnSync('git', args, { cwd, encoding: 'utf8', timeout: 10_000 });

/** A branch this checkout knows: a local head or an origin remote-tracking ref. */
export function branchExists(cwd: string, branch: string): boolean {
  return [`refs/heads/${branch}`, `refs/remotes/origin/${branch}`].some(ref => git(cwd, ['rev-parse', '--verify', '--quiet', ref]).status === 0);
}

/** One contained path segment for a branch: readable prefix plus a hash of the exact ref. */
export function branchKey(branch: string): string {
  const readable = branch.replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^[.-]+/, '').slice(0, 60) || 'branch';
  return `${readable}-${createHash('sha256').update(branch).digest('hex').slice(0, 10)}`;
}

function contained(root: string, file: string): boolean {
  const rel = path.relative(root, file);
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

/** Where a path really lands: the nearest existing ancestor with its links resolved, plus the rest of the path. */
function resolvedTarget(p: string): string {
  const rest: string[] = [];
  for (let cur = path.resolve(p); ; cur = path.dirname(cur)) {
    try { return path.join(fs.realpathSync(cur), ...rest.reverse()); } catch { if (path.dirname(cur) === cur) return path.resolve(p); rest.push(path.basename(cur)); }
  }
}

/**
 * Why this run is a fixture, or undefined: under bun test, or with its state root or repository in the temp directory.
 * A fixture's mirror must resolve inside that temp root, so a test or a probe in a scratch repository never writes
 * the owner's real Drive (GST-3027: a review probe wrote approvals/fx/qa-fixture-*.jsonl into a project-user Drive).
 */
function fixtureReason(env: Env, stateRoot: string, toplevel: string | undefined, tmpRoot: string): string | undefined {
  if (env.NODE_ENV === 'test') return 'running under bun test';
  if (contained(tmpRoot, resolvedTarget(stateRoot))) return `the state root ${stateRoot} is a temporary fixture`;
  if (toplevel && contained(tmpRoot, resolvedTarget(toplevel))) return `the repository ${toplevel} is a temporary fixture`;
  return undefined;
}

/** Where this branch's record lives, and its mirror. */
export function locate(o: { cwd: string; env: Env; branch?: string }): StoreLocation | RecordError {
  let branch = o.branch?.trim();
  if (!branch) {
    const r = git(o.cwd, ['symbolic-ref', '--short', '-q', 'HEAD']);
    branch = r.status === 0 ? r.stdout.trim() : '';
  }
  if (!branch) return { code: 'APPROVAL_RECORD_NO_BRANCH', message: `no branch at ${o.cwd} (detached HEAD or not a git repository)` };
  const stateRoot = resolveStateRoot(o.env);
  const slug = slugFromEnvironment(stateRoot, o.cwd, { scope: 'repository' }) || 'unknown';
  const dir = path.join(stateRoot, 'projects', slug, 'approvals');
  const file = path.join(dir, `${branchKey(branch)}.jsonl`);
  if (!contained(stateRoot, file)) return { code: 'APPROVAL_RECORD_INVALID', message: `record path escapes the state root: ${file}` };
  // Every mirror root this machine can see, best first; the first is written, the rest are read so a
  // row mirrored before the Captain created approvals/ (or under an explicit directory) stays visible.
  let toplevel: string | undefined | null = null;
  const repoTop = () => { if (toplevel === null) { const top = git(o.cwd, ['rev-parse', '--show-toplevel']); toplevel = top.status === 0 ? top.stdout.trim() : undefined; } return toplevel; };
  let roots: Array<[MirrorSource, string]> = [];
  if (o.env.GSTACK_APPROVALS_DIR) roots.push(['GSTACK_APPROVALS_DIR', o.env.GSTACK_APPROVALS_DIR]);
  if (o.env.GSTACK_CAPY === '1' && o.env.GSTACK_APPROVALS_MIRROR !== '0') {
    const captain = captainApprovalsDir(o.env);
    if (captain) roots.push(['captain drive', captain]);
    const folder = capyDriveFolder(o.env, repoTop() ? path.basename(repoTop()!) : undefined);
    if (folder) roots.push(['project-user drive', path.join(path.dirname(folder), 'approvals')]);
  }
  const rel = path.join(slug, `${branchKey(branch)}.jsonl`);
  for (const [, root] of roots) if (!contained(root, path.join(root, rel))) return { code: 'APPROVAL_RECORD_INVALID', message: `mirror path escapes ${root}` };
  let mirror_refused: string | undefined;
  if (roots.length) {
    const tmpRoot = resolvedTarget(os.tmpdir());
    const fixture = fixtureReason(o.env, stateRoot, repoTop(), tmpRoot);
    const escapes = ([, root]: [MirrorSource, string]) => !contained(tmpRoot, resolvedTarget(path.join(root, rel)));
    if (fixture && escapes(roots[0]!)) mirror_refused = `mirror ${path.join(roots[0]![1], rel)} (${roots[0]![0]}) resolves to ${resolvedTarget(path.join(roots[0]![1], rel))}, outside the temp root ${tmpRoot}, and ${fixture}; a fixture never writes a real Drive, so point HOME or GSTACK_APPROVALS_DIR inside the fixture or set GSTACK_APPROVALS_MIRROR=0 (the local row is kept)`;
    if (fixture) roots = roots.filter(r => !escapes(r));
  }
  const [chosen, ...rest] = mirror_refused ? [undefined, ...roots] : roots;
  return {
    file, mirror: chosen ? path.join(chosen[1], rel) : undefined, mirror_source: chosen?.[0], read_also: rest.map(r => path.join(r![1], rel)),
    ...(mirror_refused ? { mirror_refused } : {}), branch, slug, ephemeral: o.env.GSTACK_EPHEMERAL === '1',
  };
}

/**
 * The approvals directory a Captain named for its crew: exactly one mounted Captain drive
 * (`~/.capy/drive/captain-*`) holding an `approvals/` directory. Two Captains with one each
 * is ambiguous, so neither is taken and the private project-user folder stays the mirror.
 */
export function captainApprovalsDir(env: Env): string | undefined {
  if (env.GSTACK_CAPY !== '1') return undefined;
  const drive = path.join(env.HOME || os.homedir(), '.capy', 'drive');
  let found: string[];
  try {
    found = fs.readdirSync(drive).filter(d => d.startsWith('captain-')).map(d => path.join(drive, d, 'approvals')).filter(p => { try { return fs.statSync(p).isDirectory(); } catch { return false; } });
  } catch { return undefined; }
  return found.length === 1 ? found[0] : undefined;
}

function readRows(file: string | undefined): ApprovalRow[] {
  if (!file || !fs.existsSync(file)) return [];
  const rows: ApprovalRow[] = [];
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try { const r = JSON.parse(line); if (r && r.schema_version === 1 && typeof r.id === 'string') rows.push(r as ApprovalRow); } catch { /* a torn tail line is skipped, never repaired */ }
  }
  return rows;
}

export interface ReadResult { rows: ApprovalRow[]; state: 'present' | 'empty' | 'unavailable'; restored: boolean }

/** The union of the local record and its mirror (local wins on the same id), oldest first. */
export function readRecord(loc: StoreLocation): ReadResult {
  const local = readRows(loc.file);
  const mirrored = readRows(loc.mirror);
  const byId = new Map<string, ApprovalRow>();
  for (const r of [...(loc.read_also ?? []).flatMap(readRows), ...mirrored, ...local]) byId.set(r.id, r);
  const rows = [...byId.values()].sort((a, b) => a.recorded_at.localeCompare(b.recorded_at));
  const known = fs.existsSync(loc.file) || (loc.mirror !== undefined && fs.existsSync(loc.mirror));
  const state = rows.length ? 'present' : known || !loc.ephemeral || loc.mirror ? 'empty' : 'unavailable';
  return { rows, state, restored: !fs.existsSync(loc.file) && mirrored.length > 0 };
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
function validDate(d: string): boolean {
  if (!DATE_RE.test(d)) return false;
  const t = Date.parse(`${d}T00:00:00Z`);
  return !Number.isNaN(t) && new Date(t).toISOString().slice(0, 10) === d;
}

export interface NewRow { ask: string; words: string; by: string; scope: string; pending?: string; outcome?: string; date?: string; source?: string }

/** An autoplan run id as gstack-autoplan mints it: the run directory's name, a hyphen, six random letters (since GST-3015), a hyphen, then a 14-digit time stamp. */
const MINTED_RUN_ID = /^[A-Za-z0-9._-]{1,64}-\d{14}$/;
/** The part of a minted run id the exemption covers: the 14-digit stamp and, when the name ends in a thread code, its digits. */
const RUN_ID_STAMP = /(?:(?<!\d)\d{1,6}-)?\d{14}$/;

/**
 * A fix-check round grant's scope as gstack-approvals round-grant writes it (lib/review-round-grant.ts): its stop= token is the
 * /ship run id, often a PR number, a dash and a short sha (`507-7192673`), which pii.phone.e164 reads as a phone number
 * (harness-evals #507). Only a phone finding that starts inside that token of the scope field is skipped; the reason, the words
 * and every other field, a grant-shaped excerpt pasted into them included, are scanned as usual.
 */
const GRANT_STOP_SCOPE = /^review_round_grant [0-9a-f]{40} pr=[1-9]\d* kind=fix-check stop=([\w.:-]{1,120}) findings=\S+$/;
/** A rendered table row whose Covers cell, the one before Still pending, is a whole GRANT_STOP_SCOPE. */
const GRANT_STOP_ROW = /^\| .* \| (review_round_grant [0-9a-f]{40} pr=[1-9]\d* kind=fix-check stop=)([\w.:-]{1,120}) findings=[^\s|]+ \| (?:[^|\\]|\\.)* \|$/d;

/**
 * Validate and secret-scan one row; the error names the field and rule, never the text. `runId` (import only) is a
 * minted autoplan run id and the offset where the importer placed it in each field: pii.phone.e164 and pii.cc read its
 * stamp, alone or with the thread-code digits of the directory name before it, as a phone or card number (GST-2047), so
 * a finding of those two rules that starts inside that stamp part of the id, at that offset, is skipped. Anything else
 * in the field, the rest of the directory name included, and the same id typed anywhere else, is scanned as usual.
 */
export function buildRow(input: NewRow, branch: string, now = new Date(), runId?: { id: string; at: Partial<Record<'ask' | 'source', number>> }): ApprovalRow | RecordError {
  const fields = { ask: input.ask, words: input.words, by: input.by, scope: input.scope, pending: input.pending ?? 'none', source: input.source ?? 'manual' };
  for (const [k, v] of Object.entries(fields)) {
    if (typeof v !== 'string' || !v.trim()) return { code: 'APPROVAL_RECORD_INVALID', message: `--${k} is required` };
    const cap = CAPS[k as keyof typeof CAPS];
    if (v.length > cap) return { code: 'APPROVAL_RECORD_INVALID', message: `--${k} is ${v.length} characters (cap ${cap})` };
  }
  const outcome = (input.outcome ?? 'approved') as Outcome;
  if (!OUTCOMES.includes(outcome)) return { code: 'APPROVAL_RECORD_INVALID', message: `--outcome must be one of ${OUTCOMES.join('|')}` };
  const date = input.date ?? now.toISOString().slice(0, 10);
  if (!validDate(date)) return { code: 'APPROVAL_RECORD_INVALID', message: `--date must be a real YYYY-MM-DD day` };
  for (const [k, v] of Object.entries(fields)) {
    const s = scan(v);
    const at = runId && MINTED_RUN_ID.test(runId.id) ? runId.at[k as 'ask' | 'source'] : undefined;
    const stamp = at === undefined ? 0 : RUN_ID_STAMP.exec(runId!.id)![0].length;
    const inRunId = (f: Finding) => at !== undefined && (f.id === 'pii.phone.e164' || f.id === 'pii.cc') && f.line === 1 && f.col - 1 >= at + runId!.id.length - stamp && f.col - 1 < at + runId!.id.length;
    const stop = k === 'scope' ? GRANT_STOP_SCOPE.exec(v) : null;
    const stopAt = stop ? v.indexOf(' stop=') + ' stop='.length : -1;
    const inStopRun = (f: Finding) => !!stop && f.id === 'pii.phone.e164' && f.line === 1 && f.col - 1 >= stopAt && f.col - 1 < stopAt + stop[1]!.length;
    const hits = s.findings.filter(f => (f.severity === 'HIGH' || f.severity === 'MEDIUM') && !inRunId(f) && !inStopRun(f));
    if (s.oversize || hits.length) return { code: 'APPROVAL_RECORD_SECRET', message: `field ${k}: ${s.oversize ? 'oversize input' : [...new Set(hits.map(f => f.id))].join(', ')}` };
  }
  const id = 'a-' + createHash('sha256').update([fields.source, date, fields.ask, fields.words, fields.by].join('\u0000')).digest('hex').slice(0, 12);
  return { schema_version: 1, id, date, ask: fields.ask.trim(), words: fields.words.trim(), by: fields.by.trim(), scope: fields.scope.trim(), pending: fields.pending.trim(), outcome, source: fields.source, branch, recorded_at: now.toISOString() };
}

function writeMirror(loc: StoreLocation, rows: ApprovalRow[]): RecordError | undefined {
  if (loc.mirror_refused) return { code: 'APPROVAL_RECORD_WRITE_FAILED', message: loc.mirror_refused };
  if (!loc.mirror) return undefined;
  try {
    fs.mkdirSync(path.dirname(loc.mirror), { recursive: true, mode: 0o700 });
    const tmp = `${loc.mirror}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + (rows.length ? '\n' : ''), { mode: 0o600 });
    fs.renameSync(tmp, loc.mirror);
    return undefined;
  } catch (e: any) { return { code: 'APPROVAL_RECORD_WRITE_FAILED', message: `mirror ${loc.mirror}: ${e.code ?? e.message} (the local row is kept)` }; }
}

export interface AppendResult { added: ApprovalRow[]; skipped: number; mirrorError?: RecordError }

/** Append rows not already present (by id) as single-line appends, then mirror the merged record. */
export function appendRows(loc: StoreLocation, rows: ApprovalRow[]): AppendResult | RecordError {
  const have = new Set(readRecord(loc).rows.map(r => r.id));
  const fresh = rows.filter(r => !have.has(r.id));
  try {
    fs.mkdirSync(path.dirname(loc.file), { recursive: true, mode: 0o700 });
    for (const r of fresh) fs.appendFileSync(loc.file, JSON.stringify(r) + '\n', { encoding: 'utf8', mode: 0o600 });
  } catch (e: any) { return { code: 'APPROVAL_RECORD_WRITE_FAILED', message: `${loc.file}: ${e.code ?? e.message}` }; }
  const mirrorError = writeMirror(loc, readRecord(loc).rows);
  return { added: fresh, skipped: rows.length - fresh.length, ...(mirrorError ? { mirrorError } : {}) };
}

/** Re-mirror the merged record (after a failed mirror write, or to restore a local copy from the mirror). */
export function syncRecord(loc: StoreLocation): { rows: number; error?: RecordError } {
  const { rows } = readRecord(loc);
  try {
    fs.mkdirSync(path.dirname(loc.file), { recursive: true, mode: 0o700 });
    const tmp = `${loc.file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + (rows.length ? '\n' : ''), { mode: 0o600 });
    fs.renameSync(tmp, loc.file);
  } catch (e: any) { return { rows: rows.length, error: { code: 'APPROVAL_RECORD_WRITE_FAILED', message: `${loc.file}: ${e.code ?? e.message}` } }; }
  const error = writeMirror(loc, rows);
  return { rows: rows.length, ...(error ? { error } : {}) };
}

/** One Markdown table cell: no row breaks, mentions, images, links, HTML, code spans or citation-shaped text. */
export function cell(text: string, cap = 400): string {
  const clipped = text.length > cap ? text.slice(0, cap - 1).trimEnd() + '…' : text;
  return clipped
    .replace(/\r?\n+/g, ' ')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/@/g, '&#64;').replace(/\`/g, '&#96;').replace(/\[/g, '&#91;').replace(/\]/g, '&#93;').replace(/!/g, '&#33;')
    .replace(/\|/g, '\\|')
    .replace(/(approved)(\s+)(by)/gi, '$1&#32;$3');
}

/** The rendered table's header row and the footer's closing words; lib/ship-receipt-prose.ts recognizes the block by them. */
export const APPROVALS_TABLE_HEADER = '| Date | Asked | Exact words | Outcome | Covers | Still pending |';
export const APPROVALS_FOOTER_END = '(display only; not an approval citation).';

export type RepoVisibility = 'public' | 'private' | 'unknown';

/**
 * The repository's visibility as GitHub reports it through gh, for the repository gh acts on by default (GH_REPO, its
 * default repo, an upstream remote) and for the origin remote a PR is opened against: private only when every one
 * asked is private, public when any is public, and unknown for anything gh cannot answer.
 */
export function repoVisibility(cwd: string, env: Env = process.env): RepoVisibility {
  const ask = (repo: string[]): RepoVisibility => {
    const r = spawnSync('gh', ['repo', 'view', ...repo, '--json', 'visibility', '-q', '.visibility'], { cwd, env, encoding: 'utf8', timeout: 15_000 });
    if (r.status !== 0) return 'unknown';
    const v = (r.stdout ?? '').trim().toLowerCase();
    return v === 'private' || v === 'internal' ? 'private' : v === 'public' ? 'public' : 'unknown';
  };
  const origin = spawnSync('git', ['remote', 'get-url', 'origin'], { cwd, env, encoding: 'utf8', timeout: 15_000 });
  const slug = origin.status === 0 ? /([^/:]+\/[^/]+?)(?:\.git)?\/*$/.exec(origin.stdout.trim())?.[1] : undefined;
  const seen = [ask([]), ...(slug ? [ask([slug])] : [])];
  return seen.includes('public') ? 'public' : seen.every(v => v === 'private') ? 'private' : 'unknown';
}

/**
 * Full rows only where the repository is known private, or --full asks for them and GitHub does not report it public;
 * --redacted forces the redacted block anywhere, for a private repository that may go public.
 * A PR description keeps every earlier version in its edit history, so a public or unknown repository gets the
 * redacted block: whether anything was approved and an opaque id of the record (a hash of its row ids), nothing else.
 */
export function renderMode(visibility: RepoVisibility, full: boolean, redacted = false): 'full' | 'redacted' {
  if (redacted) return 'redacted';
  return visibility === 'private' || (full && visibility === 'unknown') ? 'full' : 'redacted';
}

const LOCAL_PATH = /(?<![\w.~/\\])(?:file:\/{1,2}[^\s|,;'"()<>]+|(?:~[\w.-]*|\$HOME|\$\{HOME\}|%USERPROFILE%|[A-Za-z]:)[\\/][^\s|,;'"()<>]+|\\\\[^\s\\|,;'"()<>]+\\[^\s|,;'"()<>]+|(?:[\w.-]+[\\/])*\.capy[\\/]drive[\\/][^\s|,;'"()<>]+|\/[^\s/\\|,;'"()<>]+\/[^\s|,;'"()<>]*)/gi;
const HOME_DIR = /^(?:(?:~[\w.-]*|\$HOME|\$\{HOME\}|%USERPROFILE%)[\\/]?|\/(?:home|Users)\/[^/]+\/?|[A-Za-z]:[\\/]Users[\\/][^\\/]+[\\/]?)$/i;

/**
 * A table cell with each local path replaced by `…/<file name>` (a bare home directory by `~`): absolute, home
 * (`~`, `~user`, `$HOME`, `%USERPROFILE%`), Windows-drive, UNC and `file:` paths, also glued onto a `:` or `-` (a `://` scheme prefix is never a path), and Drive-relative ones
 * (`.capy/drive/…`). The file name tells a reader what the approval counted; the directories above it name the
 * machine, the user and the Drive scope (`project-user-<project>-<person>`). A path cut by a space keeps the words
 * after the space. `gstack-approvals list` keeps the full path.
 */
export function pathLabels(text: string): string {
  return text.replace(LOCAL_PATH, m => {
    const tail = /[.:]*$/.exec(m)![0];
    const p = m.slice(0, m.length - tail.length).replace(/^file:\/*(?:localhost)?(?=\/)/i, '');
    if (HOME_DIR.test(p)) return '~' + tail;
    const name = p.split(/[\\/]/).filter(Boolean).pop();
    return name ? `…/${name}${tail}` : m;
  });
}

/** A ruled_note or gate_disposition row for a security-class finding, as the full table may show it: no fingerprint, reason or owner words (GST-3076). */
function publicRow(r: ApprovalRow): ApprovalRow {
  const fp = /^(?:ruled_note|gate_disposition) (\S+) /.exec(r.scope)?.[1];
  if (!fp || !isSecurityFinding(fp)) return r;
  const ask = r.ask.indexOf(': ') < 0 ? r.ask : r.ask.slice(0, r.ask.indexOf(': '));
  return { ...r, ask: `${ask.replace(fp, REDACTED_FINDING)}: ${REDACTED_REASON}`, scope: r.scope.replace(fp, REDACTED_FINDING), words: REDACTED_WORDS };
}

export function renderRecord(read: ReadResult, loc: StoreLocation, o: { heading?: boolean; mode?: 'full' | 'redacted' } = {}): string {
  const head = o.heading === false ? [] : ['## Approvals', ''];
  if (o.mode === 'redacted' && read.rows.length) {
    const approved = read.rows.some(r => r.outcome === 'approved' || r.outcome === 'standing');
    const id = 'r-' + createHash('sha256').update(read.rows.map(r => r.id).sort().join('\n')).digest('hex').slice(0, 12);
    return [...head, `Approved: ${approved ? 'yes' : 'no'} (record ${id}). The full approval record stays private.`, ''].join('\n');
  }
  if (read.state === 'unavailable') return [...head, `Record unavailable on this machine: no approval record for branch ${cell(loc.branch)} here, and the state root is ephemeral with no Drive mirror, so this is not proof that nothing was approved.`, ''].join('\n');
  if (!read.rows.length) return [...head, `No approvals recorded for branch ${cell(loc.branch)}.`, ''].join('\n');
  const lines = [APPROVALS_TABLE_HEADER, '|---|---|---|---|---|---|'];
  for (const row of read.rows) {
    const r = publicRow(row);
    const outcome = r.outcome === 'standing' ? 'standing approval' : r.outcome;
    lines.push(`| ${r.date} | ${cell(pathLabels(r.ask))} | “${cell(r.words, 280)}” (${cell(r.by)}) | ${outcome} | ${cell(pathLabels(r.scope))} | ${cell(pathLabels(r.pending))} |`);
  }
  return [...head, ...lines, '', `Source: gstack-approvals record for ${cell(loc.branch)} ${APPROVALS_FOOTER_END}`, ''].join('\n');
}

/**
 * Where a rendered Approvals table shows a fix-check grant's stop= run id (GST-3246): the 1-based line and column span of that token in
 * each row whose Covers cell is a whole GRANT_STOP_SCOPE, inside a table that opens with APPROVALS_TABLE_HEADER and its rule line and
 * closes on renderRecord's Source footer. gstack-post skips a pii.phone.e164 finding only inside such a span, so the same digits in any
 * other cell, in prose or in a table without that footer still report.
 */
export function approvalsGrantStopSpans(text: string): Array<{ line: number; from: number; to: number }> {
  const lines = text.split('\n');
  const spans: Array<{ line: number; from: number; to: number }> = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i] !== APPROVALS_TABLE_HEADER || lines[i + 1] !== '|---|---|---|---|---|---|') continue;
    let end = i + 2;
    while (end < lines.length && lines[end]!.startsWith('| ')) end++;
    const footer = lines[end + 1] ?? '';
    if (lines[end] !== '' || !footer.startsWith('Source: gstack-approvals record for ') || !footer.endsWith(APPROVALS_FOOTER_END)) continue;
    for (let j = i + 2; j < end; j++) {
      const m = GRANT_STOP_ROW.exec(lines[j]!);
      if (m) spans.push({ line: j + 1, from: m.indices![2]![0] + 1, to: m.indices![2]![1] });
    }
    i = end + 1;
  }
  return spans;
}

interface DecisionLike { id?: string; title?: string; status?: string; chosen?: string | null; recommended?: string | null; gate_rev?: number; answered_at?: string; answered_by?: string; reply?: string; owner_reply?: string; answer_words?: string; words_by?: string; carried_from?: string; label?: string; chosen_text?: string;
  carried_gate_from?: string; carried_gate_rev?: number; carried_answered_by?: string; carried_under?: string; carry_check?: string }

const stripRef = (t: string) => t.replace(/\s*\[[^\]]*\]\s*$/, '').trim();

/**
 * Rows for every answered gate in an autoplan run: one row per answer event (gate_rev, time, answerer), covering
 * the items it settled. Item answers carried from an earlier revision were recorded when first given and are skipped;
 * a whole gate carried forward (lib/autoplan-carry.ts) gets its own row naming the revision its words came from. Ids are stable,
 * so a rerun (or a retry after an interrupted import) adds nothing twice.
 */
export function importAutoplan(runDir: string, branch: string, by?: string): ApprovalRow[] | RecordError {
  const file = path.join(runDir, 'decisions.jsonl');
  if (!fs.existsSync(file)) return { code: 'BRIEF_INPUT_MISSING', message: `decisions.jsonl not in ${runDir}` };
  const rows: DecisionLike[] = [];
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try { rows.push(JSON.parse(line)); } catch { return { code: 'ARTIFACT_MALFORMED_JSONL', message: `decisions.jsonl has a line that is not JSON` }; }
  }
  const runFile = path.join(runDir, 'run.json');
  let run: Record<string, any> = {};
  if (fs.existsSync(runFile)) {
    try { run = JSON.parse(fs.readFileSync(runFile, 'utf8')); } catch (e: any) { return { code: 'ARTIFACT_INVALID_JSON', message: `run.json in ${runDir} is unreadable (${e?.message ?? e}); an approval names the run it came from` }; }
  }
  if (run.ceo_only || run.status === 'reviewed') return { code: 'CEO_ONLY_NO_GATE', message: `${runDir} is a CEO-only run (status ${run.status}): it has no gate and was never approved` };
  const plan = reviewedPlan(runDir, run);
  const planTitle = firstTitle(plan.text) ?? 'the plan';
  const planSha = plan.sha;
  const runId = String(run.run ?? run.id ?? path.basename(runDir));
  const answered = rows.filter(r => r.status && r.status !== 'pending' && r.answered_at && !r.carried_from);
  if (!answered.length) return { code: 'APPROVAL_IMPORT_UNANSWERED', message: `no answered gate in ${runDir}` };
  const groups = new Map<string, DecisionLike[]>();
  for (const r of answered) {
    const k = [r.gate_rev, r.answered_at, r.answered_by].join('|');
    groups.set(k, [...(groups.get(k) ?? []), r]);
  }
  const out: ApprovalRow[] = [];
  for (const group of groups.values()) {
    const first = group[0]!;
    const rev = first.gate_rev ?? 0;
    const p1 = group.find(r => (r.label ?? '').toLowerCase() === 'p1' || (r.id ?? '').endsWith('-p1'));
    const outcome: Outcome = !p1 ? 'pending' : p1.chosen === 'a' || p1.chosen === 'b' ? 'approved' : p1.chosen === 'e' ? 'rejected' : 'pending';
    const items = group.filter(r => r !== p1);
    const changed = items.filter(r => r.chosen && r.recommended && r.chosen !== r.recommended);
    const stillPending = rows.filter(r => r.gate_rev === rev && r.status === 'pending');
    const answerer = first.answered_by ?? 'unknown';
    const carried = p1?.carried_gate_from ? p1 : undefined;
    const relayed = carried?.carried_answered_by && carried.carried_answered_by !== 'human' ? `, relayed by ${carried.carried_answered_by}` : '';
    const who = first.words_by ? `${first.words_by}, its own decision (not the owner's words)`
      : carried ? `${by ?? 'the owner'} (words from gate_rev ${carried.carried_gate_rev}${relayed}), carried forward by gstack-autoplan`
      : answerer === 'human' ? (by ? `${by}, typed at the gate` : 'the owner, typed at the gate') : `${by ?? 'the owner'}, relayed by ${answerer}`;
    const unseen = items.filter(r => r.carried_under).map(r => stripRef(r.title ?? ''));
    const checked = [...new Set(items.map(r => r.carry_check).filter((c): c is string => !!c))];
    const scope = [`the reviewed plan (sha256 ${planSha}), ${changed.length ? `${changed.length} recommendation(s) changed: ${changed.map(r => stripRef(r.title ?? '')).join('; ')}` : 'every recommendation taken'}`,
      unseen.length ? `taken under "do it", not seen by the owner: ${unseen.join('; ')}` : '', checked.length ? `post-cap delta checked by ${checked.join(', ')}` : ''].filter(Boolean).join('; ');
    const askHead = `Approve the plan "${planTitle}" (autoplan run `;
    const built = buildRow({
      ask: `${askHead}${runId}, ${carried ? `gate_rev ${rev} carried forward from gate_rev ${carried.carried_gate_rev}, ` : ''}${items.length + (p1 ? 1 : 0)} decisions)`.slice(0, CAPS.ask),
      words: first.owner_reply ?? first.answer_words ?? first.reply ?? '(no words recorded)',
      by: who.slice(0, CAPS.by),
      scope: scope.slice(0, CAPS.scope),
      pending: (stillPending.length ? `${stillPending.length} decision(s) unanswered: ${stillPending.map(r => stripRef(r.title ?? '')).join('; ')}` : outcome === 'pending' ? 'the plan approval itself' : 'none').slice(0, CAPS.pending),
      outcome,
      date: first.answered_at!.slice(0, 10),
      source: `autoplan:${runId}@gate_rev=${rev}`,
    }, branch, new Date(first.answered_at!), { id: runId, at: { ask: askHead.length, source: 'autoplan:'.length } });
    if ('code' in built) return built;
    out.push(first.words_by ? { ...built, words_by: first.words_by } : built);
  }
  return out;
}

