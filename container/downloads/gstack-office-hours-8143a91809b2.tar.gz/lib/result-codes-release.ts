/**
 * Result codes for the release path: gstack-ship-queue and the ship-policy
 * floor, pregate timing and its working-tree fingerprint, regen with missing
 * dependencies, approval classes and
 * the state-machine matrix. Kept beside lib/result-codes.ts (which spreads
 * this table into RESULT_CODES) so
 * the owner module stays within the module-size ratchet; the same rules apply:
 * one stable docs/troubleshooting.md anchor, a summary and a fix clause each.
 */
import type { ResultCode } from './result-codes';

export const RELEASE_RESULT_CODES = {
  // Field list 2, W1: gstack-ship-queue and the ship-policy compatibility floor.
  POLICY_GSTACK_TOO_OLD: {
    anchor: 'policy-gstack-too-old',
    summary: 'the ship policy sets min_gstack_version above this gstack, so this gstack refuses to read it',
    fix: 'upgrade gstack (bin/gstack-upgrade, or the session install with --for <skill>) to the version named, then rerun',
  },
  POLICY_FLOOR_ABOVE_STABLE: {
    anchor: 'policy-floor-above-stable',
    summary: 'the ship policy sets min_gstack_version above the newest stable gstack release, so every stable-channel lane refuses it and no upgrade can clear that until a later release is cut',
    fix: 'set min_gstack_version to the stable release named (or lower) and drop the keys that need more, then rerun gstack-ship-policy validate',
  },
  STABLE_RELEASE_UNKNOWN: {
    anchor: 'stable-release-unknown',
    summary: 'the newest stable gstack release could not be resolved (no release tag on origin, no stable ref, no local release tag), so min_gstack_version was not compared with it; a warning, not a refusal',
    fix: 'git fetch origin --tags in the gstack checkout (or set GSTACK_STABLE_REPO to one that has them), then rerun',
  },
  PREGATE_GSTACK_TOO_OLD: {
    anchor: 'pregate-gstack-too-old',
    summary: 'the pregate policy uses a key this gstack does not know, and the project floor (min_gstack_version in .gstack/ship-policy.json) is above this gstack, so the key belongs to a newer gstack; the policy stays refused',
    fix: 'upgrade gstack (bin/gstack-upgrade, or the session install with --for <skill>) to at least the version named, then rerun',
  },
  QUEUE_NOT_READY: {
    anchor: 'queue-not-ready',
    summary: 'the lane is not ready to report: the working tree, HEAD or CI state does not match the pushed PR head',
    fix: 'commit and push the work (or wait for CI on that exact head), then rerun gstack-ship-queue ready',
  },
  QUEUE_BASE_UNFETCHED: {
    anchor: 'queue-base-unfetched',
    summary: 'ready, or the stamp path of land, could not fetch origin/<base>, so it did not compare the receipt with a base ref it could not refresh',
    fix: 'fix the fetch (git fetch origin <base>), then rerun the same command',
  },
  QUEUE_PROOF_MISSING: {
    anchor: 'queue-proof-missing',
    summary: 'a proof input the queue step needs is missing or does not match (gated head, base, stamp journal, version or tree)',
    fix: 'supply the named input (fetch the gated head, pass the expected sha), or regate; nothing was written',
  },
  QUEUE_STAMP_NOT_STAMP_ONLY: {
    anchor: 'queue-stamp-not-stamp-only',
    summary: 'the stamp commit differs from the gated head by more than stamps, so the gate does not cover it',
    fix: 'inspect the printed residual paths; drop the stray edit, or run the gate again on the stamped head',
  },
  QUEUE_VERIFY_MISMATCH: {
    anchor: 'queue-verify-mismatch',
    summary: 'the coordinator could not reproduce the lane’s stamp claim: the PR head, the recomputed gate-ahead merge or the gated tree differs',
    fix: 'do not merge; ask the lane to rerun gstack-ship-queue stamp (or gate-ahead) on the current queue and report again',
  },
  QUEUE_GATE_MISSING: {
    anchor: 'queue-gate-missing',
    summary: 'the policy sets full_e2e and no passing full-gate record is bound to this tree',
    fix: 'run the gate the policy names (gstack-ship-queue gate-ahead, then --record) or pass the record of a passing run on this head',
  },
  GATE_AHEAD_ATTEMPT_INVALID: {
    anchor: 'gate-ahead-attempt-invalid',
    summary: 'the gate-ahead attempt is unknown, already recorded, or its worktree no longer holds the gated commit',
    fix: 'list attempts with gstack-ship-queue gate-ahead --list, then record the live one, or prepare a new attempt',
  },
  // GSTA-49 lane T1: merge trains in gstack-ship-queue (docs/ship-policy.md#run-a-merge-train).
  QUEUE_TRAIN_OFF: {
    anchor: 'queue-train-off',
    summary: 'the base revision’s .gstack/ship-policy.json declares no `train` block, so the merge-train surface is off and the per-PR queue applies',
    fix: 'use the per-PR queue (ready, stamp, verify), or land a `train` block with min_gstack_version on the base branch first',
  },
  QUEUE_TRAIN_UNTRUSTED: {
    anchor: 'queue-train-untrusted',
    summary: 'a PR’s head repository is not the base repository; fork work never runs in a train (the train branch and its dispatch carry repository secrets)',
    fix: 'leave the PR out of the train (gstack-ship-queue train build --prs <list without it>); fork work stays on the trusted-branch path',
  },
  QUEUE_TRAIN_MOVED: {
    anchor: 'queue-train-moved',
    summary: 'a PR’s head (or the train branch) is no longer the SHA the train pinned, so the train would not test what merges',
    fix: 'ask the lane for a fresh READY on the new head, then rebuild the train with the new pin (train build --prs <n>@<new sha>,...)',
  },
  QUEUE_TRAIN_CONFLICT: {
    anchor: 'queue-train-conflict',
    summary: 'merging a PR onto the previous prefix conflicts outside the version files and the CHANGELOG; nothing was dispatched and no branch pushed',
    fix: 'run the printed train build without that PR; the PR’s lane merges main (with the earlier PRs once they land) and reports READY again',
  },
  QUEUE_TRAIN_FREE_RED: {
    anchor: 'queue-train-free-red',
    summary: 'the free tests dispatched on train/<nonce> are red, missing, cancelled or ran on another SHA, so the paid gate was not dispatched',
    fix: 'read the free-tests run; a PR-caused red drops that PR (train build --prs <list without it>), a flaky one goes to its owner before the next build',
  },
  QUEUE_TRAIN_DISPATCH_UNKNOWN: {
    anchor: 'queue-train-dispatch-unknown',
    summary: 'a train dispatch was attempted but its run could not be found by nonce, so whether it started is unknown; it is never re-dispatched blindly',
    fix: 'run gstack-ship-queue train status --train <nonce>: it finds the run by nonce, or marks the dispatch absent so train build --train <nonce> may dispatch it',
  },
  QUEUE_TRAIN_WAITING: {
    anchor: 'queue-train-waiting',
    summary: 'the train is below its size and its oldest READY PR has waited less than the policy’s fill time, so it does not dispatch yet',
    fix: 'add READY PRs, rerun once the printed time has passed, or pass --urgent for a one-PR train',
  },
  QUEUE_TRAIN_PENDING: {
    anchor: 'queue-train-pending',
    summary: 'the train’s run (free tests, the full gate or the bisect) has not finished, so there is no verdict yet',
    fix: 'rerun the printed NEXT: command later; nothing is dispatched again while a run is pending',
  },
  QUEUE_TRAIN_INCOMPLETE: {
    anchor: 'queue-train-incomplete',
    summary: 'the train gate did not complete its census (INFRA or INCOMPLETE panels, an unbound, partial or cancelled shard, a slice killed before upload, or no published record), so it is never green',
    fix: 'when every gap is machine-classified INFRA or INCOMPLETE, take the one re-dispatch EVAL_POLICY.infraRedispatch allows (train rebuild --train <nonce> --infra) and report both runs; otherwise diagnose the run',
  },
  QUEUE_TRAIN_RED: {
    anchor: 'queue-train-red',
    summary: 'the train’s full gate is red on the train tree; its PRs do not merge, and nothing is retried to change the verdict',
    fix: 'bisect the red cases (train bisect --train <nonce> --spend-cap <usd>); after a rebuild’s second red, route the cases to a repair lane',
  },
  QUEUE_TRAIN_RED_ON_MAIN: {
    anchor: 'queue-train-red-on-main',
    summary: 'the bisect found the red cases red on every prefix, main (T0) included: main is broken, not the train’s PRs',
    fix: 'fix forward on main first (a one-PR train), then rebuild this train unchanged',
  },
  QUEUE_TRAIN_UNATTRIBUTED: {
    anchor: 'queue-train-unattributed',
    summary: 'the bisect pattern blames no PR and not main (all green, or not monotone); one trial cannot tell a flake from a break',
    fix: 'all green: the one preregistered rebuild (train rebuild --train <nonce>), reporting both runs; any other pattern: a repair lane, then a changed train',
  },
  QUEUE_TRAIN_BISECT_CAPPED: {
    anchor: 'queue-train-bisect-capped',
    summary: 'the bisect’s reserved price (every case×prefix trial, unknown costs at the policy reservation) passes the spend cap; completed prefixes are kept and the outcome stays unattributed',
    fix: 'resume with a higher cap (train bisect --train <nonce> --spend-cap <usd>); only prefixes without a result run',
  },
  QUEUE_TRAIN_PREFIX_INVALID: {
    anchor: 'queue-train-prefix-invalid',
    summary: 'a bisect prefix is not an ancestor of the train head on train/<nonce>, or a red case is not in the gate’s plan, so the bisect inputs are refused',
    fix: 'check that train/<nonce> still points at the recorded head (train status); a moved branch needs a new train',
  },
  QUEUE_TRAIN_REBUILD_REFUSED: {
    anchor: 'queue-train-rebuild-refused',
    summary: 'the rebuild is not allowed: the bisect was not all green, the train was already rebuilt (or re-dispatched), or there is no bisect or INFRA record',
    fix: 'route the red cases to a repair lane; the train is rebuilt only once the repair merges (a changed train)',
  },
  QUEUE_TRAIN_STAMP_MISMATCH: {
    anchor: 'queue-train-stamp-mismatch',
    summary: 'a stamped train prefix S_i is not the merge of S_(i-1) and its pin modulo stamps, or differs from the plain prefix T_i outside release paths, or could not be stamped; nothing was pushed',
    fix: 'read the named slot and files: a stamp hook writing product files is fixed in the hook; otherwise rebuild the train without that slot and report it',
  },
  QUEUE_TRAIN_TREE_MISMATCH: {
    anchor: 'queue-train-tree-mismatch',
    summary: 'main’s tree is neither the train’s prefix before this PR nor after it (modulo stamps), so the merge does not publish what the gate tested',
    fix: 'stop merging; if earlier PRs of the train merged, the queue is frozen (QUEUE_TRAIN_FROZEN); otherwise rebuild the train on current main',
  },
  QUEUE_TRAIN_STALE: {
    anchor: 'queue-train-stale',
    summary: 'every slot of this train already merged on GitHub and main is a prefix another train verified, so the record is stale; comparing today’s main to its prefixes proves nothing and does not freeze the queue',
    fix: 'settle the record with train prune --stale --train <nonce>; no backstop is needed',
  },
  QUEUE_TRAIN_BASE_RED: {
    anchor: 'queue-train-base-red',
    summary: 'a conditional (base-red) PR or its fixer cannot ride this train: the train has no gates list, the fixer is not slot 1 or not in the train, two PRs declare FIXES_BASE_RED, the condition expired, or the fixer\'s own prefix is red',
    fix: 'seat the fixer (its READY declares FIXES_BASE_RED) at slot 1 of a train whose policy declares gates and build again; a red fixer prefix is the fixer lane\'s to repair, and an expired condition is reclassified by its lane',
  },
  QUEUE_TRAIN_SPEND_CAP: {
    anchor: 'queue-train-spend-cap',
    summary: 'a command gate\'s next Ubicloud run would pass the one spend cap that covers every run of the train, or UBI_OWNER is not set, so nothing more ran',
    fix: 'set UBI_OWNER to your thread code and train build --train <nonce> runs what is left; for the cap, raise the gate\'s spend_cap_usd (or lower its timeout_sec) on the base branch, then build a new train on the new main (the policy commit moves main past T0)',
  },
  QUEUE_TRAIN_LAND_METHOD: {
    anchor: 'queue-train-land-method',
    summary: 'train land must publish this slot through a tool-made update commit (a stamped train, strict branch protection, a conditional PR, or a merge that resolved release files), and the policy\'s merge method is rebase, which would replay commits instead of landing the gated tree',
    fix: 'set train.land.merge_method to squash or merge on the base branch (history merge-only allows merge only), then build a new train on the new main (the policy commit moves main off this train\'s prefixes)',
  },
  QUEUE_TRAIN_INIT_REFUSED: {
    anchor: 'queue-train-init-refused',
    summary: 'train init refuses this repository: its open PRs edit version files and the policy neither declares changelog_fragments nor stamps at merge, so every train merge would conflict on the version',
    fix: 'adopt changelog_fragments (recommended) or queue_mode stamp-at-merge on the base branch first, then run train init again',
  },
  QUEUE_TRAIN_DOCTOR_FINDINGS: {
    anchor: 'queue-train-doctor-findings',
    summary: 'train doctor found the live train block out of step with the repository: a gate workflow missing, without the nonce input or run-name, a required job it does not define, a global concurrency group, a push trigger on train-prefix/ refs, a workflow never green on the base, or a merge method GitHub refuses',
    fix: 'fix each FINDING line on the base branch (train init prints the workflow snippet), then run train doctor again',
  },
  QUEUE_BASE_RED_NO_TRAIN: {
    anchor: 'queue-base-red-no-train',
    summary: 'a conditional READY (ready --base-red) needs a train that gates every prefix, and the base policy has no train block with gates',
    fix: 'wait for the base to pass the cases and run /ship --resume (the normal READY follows), or turn on a train with gates on the base branch',
  },
  SHIP_BASE_RED_FIXER: {
    anchor: 'ship-base-red-fixer',
    summary: 'ready --base-red names no fixer PR, or the receipt\'s base-red condition no longer matches the base: a conditional READY needs an owner for its condition and a current classification',
    fix: 'pass --fixer <pr> naming the open PR whose merge fixes the cases; when the base moved, rerun gstack-base-red classify (and /ship) first',
  },
  QUEUE_TRAIN_FROZEN: {
    anchor: 'queue-train-frozen',
    summary: 'a train stopped partway through publication, or the main backstop was red, so main holds a tree no gate passed; ordinary trains and lands are refused until a repair lands',
    fix: 'admit one repair PR at its exact head (train build --repair --prs <n>@<sha>; under merge: direct, land --pr <n> --pin <sha> --repair); the freeze clears when verify finds main’s tree after that merge in a green record, or, under merge: direct, when the main backstop is green on a main that contains it',
  },
  // Wave PRs (Garry R46, GST-574; docs/ship-policy.md#wave-prs): 3-6 same-area PRs in one train slot.
  QUEUE_WAVE_CONFLICT: {
    anchor: 'queue-wave-conflict',
    summary: 'a constituent conflicts with the wave built so far beyond the CHANGELOG and the stamp files; nothing was pushed',
    fix: 'resolve the merge in the printed worktree, commit it, then wave build --wave <nonce> --continue; or rebuild the wave without that PR',
  },
  QUEUE_WAVE_MOVED: {
    anchor: 'queue-wave-moved',
    summary: 'a constituent is no longer open at its pinned head or targets another branch, the wave branch no longer merges every pin unchanged, the wave was rebuilt or released, or its wave PR is still open for a drop or release',
    fix: 'close the wave PR, rebuild without the moved PR (wave build --wave <nonce> --drop <pr>) and READY the new wave PR; the moved PR goes back to its owner',
  },
  QUEUE_WAVE_DUPLICATE: {
    anchor: 'queue-wave-duplicate',
    summary: 'a PR would land twice: it is already in another live wave, pinned as its own slot beside its wave, or is itself a wave PR',
    fix: 'keep each PR in one place: drop the separate pin from the train, or rebuild one of the waves without it',
  },
  QUEUE_WAVE_SIZE: {
    anchor: 'queue-wave-size',
    summary: 'a wave carries 3 to 6 PRs by default (--min, --max), and this one has fewer or more',
    fix: 'add or remove PRs (wave plan suggests area groups); fewer than the minimum ride as single slots',
  },
  QUEUE_WAVE_UNKNOWN: {
    anchor: 'queue-wave-unknown',
    summary: 'a wave/<nonce> branch or nonce has no wave record in local state or refs/notes/gstack-trains, so its constituents cannot be checked',
    fix: 'run wave status to list known waves; rebuild the wave with wave build --prs when the record is gone',
  },
  QUEUE_WAVE_DEPENDENT: {
    anchor: 'queue-wave-dependent',
    summary: 'the PR to drop is contained in another constituent’s pin, so the rebuilt wave would still land its code',
    fix: 'drop the containing PR too, or keep the PR in the wave',
  },
  QUEUE_WAVE_NOT_MERGED: {
    anchor: 'queue-wave-not-merged',
    summary: 'wave settle found no merged PR for the wave branch, or main’s merge does not carry the wave head',
    fix: 'land the wave PR through its train (train land), then rerun wave settle --wave <nonce>',
  },
  // CREW rule 22 (Garry, 2026-10-25): /ship runs before every READY; the queue refuses a PR whose body has no current receipt.
  QUEUE_RECEIPT_MISSING: {
    anchor: 'queue-receipt-missing',
    summary: 'the PR body carries no valid /ship receipt, so the PR was never shipped through gstack and cannot be READY’d, admitted to a train or merged',
    fix: 'run /ship on the branch (unattended it writes the receipt into an open PR at HEAD with gstack-ship-receipt write --pr <n> --body …, else leaves it in .gstack/tmp/ship-receipt.md for the parent to post), then gstack-ship-queue ready again; there is no flag to skip this',
  },
  QUEUE_RECEIPT_STALE: {
    anchor: 'queue-receipt-stale',
    summary: 'the PR body’s /ship receipt is for another head than the one being READY’d or merged (a push after /ship, or a receipt copied from another PR)',
    fix: 'rerun /ship on the current head so the receipt names it, then gstack-ship-queue ready again; a slot’s stamp commit keeps the receipt written for its pinned head',
  },
  QUEUE_RECEIPT_CONDITIONAL: {
    anchor: 'queue-receipt-conditional',
    summary: 'the PR body’s /ship receipt is conditional: Step 5 failed on cases gstack-base-red proved are the base branch’s own, so /ship paused before READY',
    fix: 'wait for the base to pass those cases (gstack-base-red wait --pause <file>), then /ship --resume <record>, which re-runs Step 5 and rewrites the receipt without base_red; only ready --base-red --fixer <pr> READYs a conditional receipt, and it rides only a train with gates whose slot 1 is its fixer',
  },
  QUEUE_RECEIPT_BASE_MISMATCH: {
    anchor: 'queue-receipt-base-mismatch',
    summary: 'the PR body’s /ship receipt was reviewed against another branch than the queue’s base (a #3570 stacked child retargeted before its parent landed), so it covers only the change since that branch',
    fix: 'land the parent first, merge the base into this branch and push, then gstack-ship-receipt carry --pr <n> --base <base> moves the receipt to the base (it carries only when the parent fully landed and the child is unchanged), else rerun /ship against the base; then gstack-ship-queue ready again',
  },
  BASE_RED_UNCONFIGURED: {
    anchor: 'base-red-unconfigured',
    summary: 'the base branch’s ship policy declares no base_red block, so gstack-base-red cannot reproduce a Step 5 failure there and every failure stays in-branch',
    fix: 'handle the failure with /ship’s usual triage; to let /ship pause on a red base, add base_red { setup, select, timeout_sec } to .gstack/ship-policy.json on the base branch',
  },
  BASE_RED_UNNAMED: {
    anchor: 'base-red-unnamed',
    summary: 'the failure evidence names fewer failures than the Step 5 lane reported, so an unnamed failure could be in-branch',
    fix: 'list every failing test in the evidence file (id, file, first error line), with total equal to the lane’s failure count, and classify again',
  },
  BASE_RED_REPRO_ERROR: {
    anchor: 'base-red-repro-error',
    summary: 'gstack-base-red could not reproduce at the base or the PR head: a commit did not resolve, the scratch checkout failed, or the setup command exited non-zero',
    fix: 'read the printed detail; fix the base_red setup command on the base branch or fetch the base, then classify again. Until then every failure is in-branch',
  },
  BASE_RED_PAUSE_EXPIRED: {
    anchor: 'base-red-pause-expired',
    summary: 'the base-red pause is older than 24 hours, so its classification is stale',
    fix: 'report the paused PR to its Captain (or owner), then start /ship again on the current base; it classifies afresh',
  },
  BASE_RED_WAIT_TIMEOUT: {
    anchor: 'base-red-wait-timeout',
    summary: 'no new base head passed the paused cases before gstack-base-red wait’s timeout',
    fix: 'run gstack-base-red wait --pause <file> again (the pause stays valid until it expires), or check who owns the base red',
  },
  BASE_CONTAINS_HEAD: {
    anchor: 'base-contains-head',
    summary: 'the base is the head or already contains it while the branch has commits its real base lacks, so a base-relative step would compare the branch with itself and report no changes',
    fix: 'compare against the branch’s real base (the PR’s base branch, usually main): pass it as the base, or run git remote set-head origin <base> when origin/HEAD names the checked-out branch',
  },
  QUEUE_RECEIPT_DEPTH_RAISED: {
    anchor: 'queue-receipt-depth-raised',
    summary: 'the PR body’s /ship receipt records a review depth below the one its head needs (the queue recomputed it from git), or a current receipt records no review_depth at all',
    fix: 'run /ship on the head the READY names; the REVIEW_DEPTH line shows the receipt’s depth, the required depth, its reasons and inputs, and the receipt is left unchanged',
  },
  QUEUE_RECEIPT_EXCEPTION_INVALID: {
    anchor: 'queue-receipt-exception-invalid',
    summary: 'the PR body’s /ship receipt records an owner exception (docs or review loop) that is malformed, lacks the fix-check it follows, or whose line the body no longer carries verbatim',
    fix: 'restore the exception line in the PR body word for word, or run /ship again and record the owner’s acceptance with --docs or --review-loop-exception',
  },
  QUEUE_RECEIPT_TARGETED_MISSING: {
    anchor: 'queue-receipt-targeted-missing',
    summary: 'the head touches money, gate, auth or secret code that needs the targeted reader, and the PR body’s /ship receipt records no done targeted pass covering every required class (none recorded, failed, not run, or other classes)',
    fix: 'run /ship on the head the READY names so the targeted reader covers every class the REVIEW_TARGETED line lists as required; the receipt is left unchanged',
  },
  QUEUE_SCREEN_STALE_REF: {
    anchor: 'queue-screen-stale-ref',
    summary: 'GitHub’s refs/pull/<n>/merge is missing or still merges an older head than the PR’s: the PR conflicts with the base (a CHANGELOG-only conflict counts), so a screen dispatched on it would plan no cases and report success',
    fix: 'resolve the conflict with the base branch (or wait for GitHub to recompute the merge ref), push, then gstack-ship-queue ready --pr <n> --screen again; a lane never READYs on a screen that planned nothing',
  },
  QUEUE_SCREEN_NOT_RUN: {
    anchor: 'queue-screen-not-run',
    summary: 'the PR’s dispatched screen run concluded success but ran no slice (the run planned no cases: its route job found the PR head superseded by a push, or the plan selected nothing), so the head is not screened and the run is counted as not-run, never as green',
    fix: 'gstack-ship-queue ready --pr <n> --screen dispatches a fresh screen at the current head (a not-run screen is never followed); train build seats the pin unscreened and says so on its SCREEN: line',
  },
  QUEUE_TRAIN_STACK_RED: {
    anchor: 'queue-train-stack-red',
    summary: 'train build --dry-run --stack-tests ran a PR’s new test files on the integrated prefix that includes it (T<k>: main plus every slot up to that PR) and they failed; the tests pass on the PR head alone only because nothing before it in the train had changed what they read',
    fix: 'fix the PR’s tests against that prefix (read the STACK_TESTS: line for the files and the failing assertion), or reorder the train with --order so the PR they depend on comes first, then rerun the dry run; nothing was written, pushed or dispatched',
  },
  QUEUE_POST_MERGE_RED: {
    anchor: 'queue-post-merge-red',
    summary: 'a push workflow on the merged commit (free tests, the Windows subset, the main backstop) concluded failure, timed out or was cancelled after the train merged it; a neutral or skipped check is not red',
    fix: 'read the red run (gstack-ship-queue verify --post-merge <sha> prints one CHECK: line per workflow), repair on a new PR or roll back the merge; gstack-ship-queue train status names the freeze if the backstop filed one',
  },
  QUEUE_READY_NOTE_UNPUSHED: {
    anchor: 'queue-ready-note-unpushed',
    summary: 'ready wrote its READY receipt locally, but after three tries origin does not hold the note on refs/notes/gstack-trains (the push failed, or it exited 0 and origin read back without the note), so land would refuse the pin; the head is not READY',
    fix: 'read the push error on the READY_RECEIPT line, fix what refused it (credentials, a hook or rule on refs/notes/*, the network), then rerun the printed gstack-ship-queue ready command, adding back any --pregate, --gate-exit or --gate-log you passed; it keeps ready_at and pushes the kept receipt',
  },
  QUEUE_SCREEN_RED: {
    anchor: 'queue-screen-red',
    summary: 'the PR head’s dispatched screen run finished RED (its gate binding says so; a case that failed twice is real), so the head is not READY and a train will not seat it',
    fix: 'read the SCREEN_VERDICT line (gstack-ship-queue verify --pr <n> --screen prints the red and flaky cases), repair, push a new head, run /ship and ready again; a red screen is never re-dispatched at the same merge SHA',
  },
  READY_SCREEN_CHOICE_REQUIRED: {
    anchor: 'ready-screen-choice-required',
    summary: 'the base policy turns trains on, so READY needs an explicit screen choice: --screen (pay for a diff-relevant screen now) or --no-screen',
    fix: 'rerun gstack-ship-queue ready with the printed recommendation (--screen or --no-screen); say in the READY block if focused local cases already ran',
  },
  // Field list 2 W4 (pregate `timing`).
  PREGATE_TIMING_ASSERTION: {
    anchor: 'pregate-timing-assertion',
    summary: 'an added or changed test line compares an elapsed wall-clock or CPU time against a bound, or sleeps and then asserts (a warning, not a block)',
    fix: 'assert on the outcome, an injected clock or a forced deadline instead; when the bound is the contract, add `gstack-timing-ok: <reason>` in a comment on the line or the line above',
  },
  // Lane D (GSTA-112): the no-policy warning and the environment-cause verdict.
  PREGATE_NO_POLICY: {
    anchor: 'pregate-no-policy',
    summary: 'the repository has no pregate policy yet (no .gstack/pregate.json on the base branch and no user-owned file), or its policy declares no lanes (no dependencies, empty_lanes, selection or local key), and a touched file maps to no test lane; a warn, with a starter policy printed',
    fix: 'review the printed starter, write it with `gstack-pregate init` (or add its dependencies to the existing policy), edit the TODO entries, then commit .gstack/pregate.json on the base branch; from then on an unmapped file is PREGATE_NO_LANE',
  },
  PREGATE_ENVIRONMENT: {
    anchor: 'pregate-environment',
    summary: 'a check could not run because of the machine, not the diff: a runner or guard binary missing from PATH, a network error or quota refusal before any test ran, a full disk, or an unverified runtime; incomplete, never pass',
    fix: 'read the `environment:` line (kind and evidence), repair that on this machine or run the lane remotely (`--remote`, `gstack-pregate clear`), then rerun; a waiver cites the kind, never a test name',
  },
  // Field list 2, W2 (approval classes) and W3 (state-machine round-trip matrix).
  APPROVAL_CLASSES_INVALID: {
    anchor: 'approval-classes-invalid',
    summary: '`.gstack/approval-classes.json` is malformed, a class matches nothing, or a path escapes the repository',
    fix: 'keep `classes` a non-empty list of uniquely named classes, each with `paths`, `patterns` or `migrations: true`, and every glob repo-relative (`gstack-approval-classes validate` checks the working-tree copy)',
  },
  APPROVAL_CLASS_FOUND: {
    anchor: 'approval-class-found',
    summary: 'the branch changes something a declared approval class covers',
    fix: 'get the owner\'s approval and put `Approved by <owner> <YYYY-MM-DD> via <plan sha|comment or review URL> for <class>@<digest12>` in the PR body, using the APPROVAL_SCOPE token the check printed',
  },
  APPROVAL_CITATION_MISSING: {
    anchor: 'approval-citation-missing',
    summary: 'a declared approval class has no citation that resolves and binds to its current effects, so no receipt was written',
    fix: 'add an `Approved by` line whose plan (with --approval-run <dir>) or maintainer comment names the APPROVAL_SCOPE token or the class and every effect path; for evidence gstack cannot read, attest it with `for <class>@<digest12>` on the line. Only the owner approves: never write the line without their approval',
  },
  APPROVAL_SOURCE_UNAVAILABLE: {
    anchor: 'approval-source-unavailable',
    summary: 'origin/<base> is not a resolvable commit, so the committed .gstack/approval-classes.json cannot be read and nothing was checked',
    fix: 'git fetch origin <base> (classes are never read from the working tree)',
  },
  STATE_MATRIX_INCOMPLETE: {
    anchor: 'state-matrix-incomplete',
    summary: 'the state-machines specialist output lacks a kind × owner action cell, maps a cell to a test that does not exist, or leaves an untested cell without a CRITICAL finding',
    fix: 'rerun the state-machines specialist on the same diff; its review coverage stays incomplete until gstack-state-matrix check passes',
  },
  // Fix wave 2026-10-15, PR 5 (item 10b, #3197).
  WTREE_UNAVAILABLE: {
    anchor: 'wtree-unavailable',
    summary: 'cannot fingerprint the working tree: bin/gstack-wtree could not start (on Windows, no Git Bash was found) or it ran and failed',
    fix: 'on Windows point GSTACK_GIT_BASH at Git Bash\'s bash.exe (Git Bash: export GSTACK_GIT_BASH=\'C:/Program Files/Git/bin/bash.exe\'; PowerShell: $env:GSTACK_GIT_BASH = \'C:\\Program Files\\Git\\bin\\bash.exe\'), or install Git for Windows (winget install --id Git.Git -e); elsewhere rerun ./setup so bin/gstack-wtree is present; then rerun gstack-pregate',
  },
  // Fix wave W5 (GSTA-31): pregate regen without installed dependencies.
  REGEN_DEPS_MISSING: {
    anchor: 'regen-deps-missing',
    summary: 'a regen command exited 0 with different outputs while package.json declares dependencies and node_modules is missing, so the outputs were not verified',
    fix: 'install the dependencies (the printed command, such as bun install), then rerun the check',
  },
  // The /ship review loop's finding scope (gstack-review-scope) and the receipt carry (gstack-ship-receipt carry).
  REVIEW_SCOPE_INPUT: {
    anchor: 'review-scope-input',
    summary: 'gstack-review-scope was given input it cannot classify: findings that are not a JSON array of objects, a --pass or --policy outside its values, or a pass 2+ call without --range-base',
    fix: 'pass the Step 9.3 findings as a JSON array (--findings <file> or stdin), --pass <n> from the invocation record, and from pass 2 on --range-base <sha> (HEAD at the start of the previous pass)',
  },
  REVIEW_SCOPE_RANGE: {
    anchor: 'review-scope-range',
    summary: 'gstack-review-scope could not read the diff it scopes findings against: the base or the range base does not resolve, or the range base is not an ancestor of HEAD',
    fix: 'fetch origin/<base>, check --range-base against the saved pass heads, and start a full pass (--pass 1) when history was rewritten',
  },
  REVIEW_SCOPE_LEDGER: {
    anchor: 'review-scope-ledger',
    summary: 'gstack-review-scope summary could not count the dispatch ledgers: none was named (no --run, --ledger or --no-ledger), --run holds no review-ledger.jsonl, or a ledger, its merged file or its judged set is unreadable or changed since judge',
    fix: 'pass --run <run dir> (the directory the review passes wrote) or each --ledger <f>; --no-ledger only when no reader ran through gstack-review-dispatch; restore or re-collect a ledger file that moved',
  },
  RECEIPT_CARRY_REFUSED: {
    anchor: 'receipt-carry-refused',
    summary: 'gstack-ship-receipt carry could not carry the /ship receipt to HEAD: the PR body has no receipt, the working tree has uncommitted changes, the receipt head is not an ancestor of HEAD and the receipt records no tree to compare, or the product diff could not be compared',
    fix: 'commit or stash working-tree changes and rerun carry; when history was rewritten and the receipt predates head_tree, run /ship on the new head (merge the base in instead of rebasing next time)',
  },
  PROSE_LINT_FOUND: {
    anchor: 'prose-lint-found',
    summary: 'the prose /ship is about to publish (a CHANGELOG entry or a PR body) carries an AI tell a regular expression can decide',
    fix: 'rewrite each PROSE: line in the draft the way its hint says, then rerun gstack-prose-lint on the same file',
  },
  RECEIPT_BLOCKER_OPEN: {
    anchor: 'receipt-blocker-open',
    summary: 'the review loop stopped at this head with a blocking finding still open (a Step 9 or Step 11 finding, the second-model review included, whose newest review-log action is still open and no owner ruling closed), so no receipt is written',
    fix: 'fix the finding and run /ship again on the new head, or take the stop to the owner, whose ruled note or grant closes it; never write the receipt by hand or drop the finding from the review-log row',
  },
  REVIEW_LOOP_EXCEPTION_INVALID: {
    anchor: 'review-loop-exception-invalid',
    summary: 'write --review-loop-exception got an exception that is malformed, accepts a stop the review loop does not show (a fix_check with review_loop.fix_checks 0 or missing, or a second_pass with fewer than two passes or no deferred finding), names a head that is not the receipt head or its ancestor, or is missing from the PR body',
    fix: 'pass { accepted_by, date, via, reason } plus fix_check: { head, findings } or second_pass: { head, deferred: [<finding id>] } with the owner’s words, the --review-loop summary that shows that stop, and the printed "Review-loop exception: …" line in the body',
  },
  CI_CARRY_TREE_LOG_UNBOUND: {
    anchor: 'ci-carry-tree-log-unbound',
    summary: 'a CI run with no tree.json artifact (artifact storage full) has one GSTACK_TREE_JSON line in its job log, but the runner did not stamp it inside the step the run profile names in tree_log_step, at least a second after every earlier step ended and a second before every later one started, or that step is missing, repeated or did not succeed; a line printed anywhere else (a test, for one) is never evidence',
    fix: 'print the line only from the step tree_log_step names, after the test step, with sleep 1 before it and sleep 5 after it (docs/pregate.md#tree-log-step); then dispatch a fresh run at the same head and rerun gstack-ci-carry wait',
  },
  CI_CARRY_RERUN_MALFORMED: {
    anchor: 'ci-carry-rerun-malformed',
    summary: 'a CI run\'s tree.json carries rerun_files or attempts in a shape gstack cannot read (rerun_files not a list of paths, attempts not a list of attempt numbers), so the run is not evidence and no lane carries from it',
    fix: 'fix the workflow step that writes tree.json (rerun_files: ["test/a.test.ts", …], attempts: [1, 2]), dispatch a fresh run at the same head, then rerun gstack-ci-carry wait',
  },
  RECEIPT_CARRY_TREE_MISMATCH: {
    anchor: 'receipt-carry-tree-mismatch',
    summary: 'the branch was rebased or force-pushed since its /ship receipt, and HEAD\'s tree is not a tree the receipt covers, so no review saw this code',
    fix: 'run /ship on the new head; next time merge the base in instead of rebasing a reviewed branch (a rebase carries only onto a reviewed tree with the reviewed product diff)',
  },
  RECEIPT_CARRY_PRODUCT_CHANGED: {
    anchor: 'receipt-carry-product-changed',
    summary: 'the product diff against the base changed between the receipt\'s head and HEAD (a product file differs beyond a base merge, a test-only fix, release metadata or a regenerated output), so the reviewed verdict does not cover HEAD',
    fix: 'run /ship on the new head; the receipt carries only when every changed path is a test, release metadata, a registered output the pregate regen check proved, or the base merge, and the product patch-id is unchanged; base context next to unchanged reviewed hunks is RECEIPT_CARRY_SCOPED_REVIEW instead (one scoped fix-check, no /ship)',
  },
  STOP_UNBOUND: {
    anchor: 'stop-unbound',
    summary: 'gstack-ship-receipt stop found no review of this run bound to one committed tree, so it recorded no stop record',
    fix: 'nothing for a grant to answer: the lane or its Captain ships with the open notes listed or parks; a fresh /ship run gives the head its review',
  },
  GRANT_SPENT: {
    anchor: 'grant-spent',
    summary: 'another /ship run already claimed this round grant, and a grant buys one round',
    fix: 'the lane or its Captain records a new grant for the stop the PR is at now (gstack-ship-receipt stop prints the command)',
  },
  SHIP_RUN_ABANDON_REFUSED: {
    anchor: 'ship-run-abandon-refused',
    summary: 'gstack-ship-run abandon left the /ship run record as it was: the run beat in the last 60 minutes, the record names another run or already ended, or an unreadable record\'s digest did not match',
    fix: 'read gstack-ship-run status: wait until the earliest abandon time it prints if the run may still be working, pass the run it names (an unreadable record: --run unknown --sha256 <its digest>), and leave an ended run alone',
  },
  SHIP_RUN_RECORD_UNREADABLE: {
    anchor: 'ship-run-record-unreadable',
    summary: 'this checkout\'s /ship run record (git dir gstack-ship-run) is neither a run record nor a run id, so every guard reads it as an open run',
    fix: 'if no /ship run is working on this checkout, end it with the gstack-ship-run abandon --run unknown --sha256 <digest> command status prints, once',
  },
  GRANT_UNKNOWN: {
    anchor: 'grant-unknown',
    summary: 'the branch approval record holds no approved review_round_grant row with this id',
    fix: 'pass the id gstack-approvals round-grant printed, from a checkout that sees the record or its mirror',
  },
  RECEIPT_CARRY_SCOPED_REVIEW: {
    anchor: 'receipt-carry-scoped-review',
    summary: 'the branch\'s own +/- lines are the reviewed ones, but the base edited context next to them, so the merge may have spliced the two (GST-384); the receipt carries only after a scoped review of those hunks',
    fix: 'dispatch one fix-check reviewer on the packet the refusal names, write its clean verdict as { head, paths, reviewer, verdict } and rerun carry with --scoped-review <record.json>; a blocking finding means /ship on the new head',
  },
  RECEIPT_DOCS_AUDIT_READ: {
    anchor: 'receipt-docs-audit-read',
    summary: 'the Step 14.5 docs audit edited a doc the review read for its own content (a gate path, gate tags, agent prose or a secret line) after the review, so the receipt binds only after one scoped reader reads that change (GST-3532); it is not a review round',
    fix: 'dispatch one reader on the packet the refusal names, write its clean verdict as { head, paths, reviewer, verdict, packet_sha256 } and rerun write with --docs-audit-read <record.json>; a finding goes to the lane\'s Captain',
  },
  DOCS_AUDIT_BLOCKED: {
    anchor: 'docs-audit-blocked',
    summary: 'the documentation audit (/ship Step 14.5) is blocked: gstack-ship-receipt docs-caps found a declared doc cap over, or gstack-ship-receipt write was given a blocked audit with no owner exception and refused to record the ship as audited',
    fix: 'repair the audit (or trim the doc named by the DOCS_CAP: over line) and rerun Step 14.5; when the owner accepts the named risk, record it as docs.exception { accepted_by, date, via, reason } and carry the same line in the PR body\'s Documentation section',
  },
  DOCS_RESULT_INVALID: {
    anchor: 'docs-result-invalid',
    summary: 'the documentation audit child\'s last line (/ship Step 14.5) does not meet the result contract: a key is missing, unknown or repeated once whitespace around keys is trimmed, a field has the wrong type or value, or documentation_section is empty or a placeholder; the audit result cannot be used, and this is a malformed reply, not a blocked audit',
    fix: 'on FORMAT_REPAIR:, re-ask once for the last line with gstack-docs-candidate repair-prompt and check the reply with result --repair-of, which uses no attempt; otherwise run the one remaining re-audit with the RETRY_NOTE: line appended to its prompt verbatim; with no attempt left, Step 14.5 stops with this code and the keys it names',
  },
  RECEIPT_PROSE_MISMATCH: {
    anchor: 'receipt-prose-mismatch',
    summary: 'the PR body quotes a counter the ship receipt also records (review passes, deferred findings, gate case counts) with a different number, so the prose and the receipt disagree about the same run',
    fix: 'correct the body to the receipt\'s number (the PROSE: line names each field with both values); when the receipt is the stale one, rerun /ship so the receipt is rewritten from the run',
  },
  RECEIPT_CARRY_PREGATE_STALE: {
    anchor: 'receipt-carry-pregate-stale',
    summary: 'gstack-ship-receipt carry would rebind a receipt that records a pregate without a pregate result current for HEAD, so the carried receipt would claim the old tree\'s checks',
    fix: 'run gstack-pregate at HEAD (the remote tests stage when the policy requires it), then rerun carry with --pregate <pregate.json>',
  },
  RECEIPT_GIT_TOO_OLD: {
    anchor: 'receipt-git-too-old',
    summary: 'gstack-ship-receipt carry needs git 2.39 or later for `git patch-id --verbatim`; the installed git is older, so the product diff could not be compared',
    fix: 'upgrade git to 2.39 or later (the refusal names the installed version), then rerun carry; otherwise run /ship on the new head',
  },
  // Changelog fragments and the per-PR merge step (lib/changelog-fragments.ts, lib/ship-queue-land.ts).
  CHANGELOG_FRAGMENT_INVALID: {
    anchor: 'changelog-fragment-invalid',
    summary: 'a CHANGELOG fragment is not one regular .md file directly in the fragment directory with entry text, optional bump and important front matter and no release heading, or one of that name already landed with other text',
    fix: 'rewrite the named fragment as a flat <dir>/<slug>.md with only the entry text (and optional "bump: minor|major" and "important: security|regression|data-loss|blocker" front matter), rename it if the name already landed, then rerun',
  },
  QUEUE_LAND_LOCKED: {
    anchor: 'queue-land-locked',
    summary: 'another gstack-ship-queue land or train land slot holds the repository land lock (refs/notes/gstack-land), so this one would race it onto main',
    fix: 'wait for the holder named in the line to finish; if it crashed, rerun with --break-lock (refused while it is mid-push or mid-merge, between train slots less than 10 minutes, and for a live train run without --break-train-lock)',
  },
  // #3531: verify --train's slot stamp proof and gstack-restamp's staging of what it writes.
  QUEUE_TRAIN_UNSTAMPED: {
    anchor: 'queue-train-unstamped',
    summary: 'the slot head verify --train would let merge is not stamped above main: its VERSION is not above main\'s, or its CHANGELOG is not headed with that version directly above main\'s top release',
    fix: 'on the lane, run gstack-restamp --next on the head, commit what restamp staged, push, then rerun gstack-ship-queue verify --pr <n> --train <nonce>',
  },
  RESTAMP_NOT_STAGED: {
    anchor: 'restamp-not-staged',
    summary: 'gstack-restamp wrote the stamp but could not stage it, so a bare git commit would leave the stamp out',
    fix: 'clear what blocked git add (an index.lock), then rerun gstack-restamp: the noop rerun stages the files it wrote, or drops the marker when they changed since',
  },
  RESTAMP_UNSTAGED_EDITS: {
    anchor: 'restamp-unstaged-edits',
    summary: 'a file gstack-restamp would stamp holds unstaged edits of the caller, which staging the stamp would sweep into the stamp commit; nothing was written',
    fix: 'stage (git add) or stash your own edits to the files named, then rerun gstack-restamp',
  },
  QUEUE_LAND_CONFLICT: {
    anchor: 'queue-land-conflict',
    summary: 'the PR conflicts with the base branch in product files (or a release field cannot be resolved alone), so the merge step cannot stamp it',
    fix: 'the lane merges the base branch into the PR, resolves the named files, runs /ship and reports READY again',
  },
  QUEUE_LAND_DRIFT: {
    anchor: 'queue-land-drift',
    summary: 'the base branch moved between the merge step\'s last check and the squash merge, so main\'s tree is not the stamped tree land verified',
    fix: 'gstack-ship-queue land --pr <n> --repair opens a PR whose only change is a fragment for what the outside merge brought; /ship and land it, which releases the lock',
  },
  QUEUE_LAND_BASE_BUSY: {
    anchor: 'queue-land-base-busy',
    summary: 'the base branch moved during the stamp commit\'s CI on each of the allowed restamp attempts, so land stopped instead of restamping again',
    fix: 'find what is merging outside land (every merge should go through it), then rerun gstack-ship-queue land --pr <n>; it resumes from its journal',
  },
  // gstack-ship-queue land --pin (lib/ship-queue-land-direct.ts): merge: direct refusals and its post-merge check.
  QUEUE_LAND_STAMPED: {
    anchor: 'queue-land-stamped',
    summary: 'under merge: direct the PR changes VERSION, the package.json version or the CHANGELOG; versions and the CHANGELOG are set at release, so a PR carries only its changelog fragment',
    fix: 'put the named files back to the merge base (git checkout $(git merge-base origin/main HEAD) -- <files>), keep or add the changelog.d fragment, commit, then /ship and ready at the new head',
  },
  QUEUE_LAND_PIN_MOVED: {
    anchor: 'queue-land-pin-moved',
    summary: 'the PR head is not the pin land was given, so the READY it was given does not describe what would merge',
    fix: 'the lane runs /ship and gstack-ship-queue ready --pr <n> --no-screen at the new head and reports READY with it; land that pin',
  },
  QUEUE_GATE_DISPOSITION: {
    anchor: 'queue-gate-disposition',
    summary: 'the owner gate dispositions the approval store applies at the pin are not all accepted by the lander, an accepted id is not applied, or the receipt or PR body differs from the store',
    fix: 'read each GATE_DISPOSITION line, then rerun land (or verify) with --accept-gate-disposition <approval id> for each one you accept; when the receipt or body differs from the store, the lane reruns /ship and ready at the pin',
  },
  QUEUE_LAND_CHECKS: {
    anchor: 'queue-land-checks',
    summary: 'a check at the pin is red or pending, or a required check never ran there',
    fix: 'wait for pending checks (gstack-pr-wait <n> --until green), fix a red one at a new head, or dispatch a missing required workflow on the branch; then rerun land',
  },
  QUEUE_LAND_MERGED_CHECKS: {
    anchor: 'queue-land-merged-checks',
    summary: 'the base moved past the pin\'s merge base, and a land.merged_checks command failed on the pin merged onto the base tip (GST-1316: a stale-base PR pushed a budgeted file past its cap on main); nothing merged',
    fix: 'merge the base into the branch, fix what the failing command names, push, wait for the required checks, run /ship and gstack-ship-queue ready at the new head, then land it',
  },
  QUEUE_LAND_NOT_CLEAN: {
    anchor: 'queue-land-not-clean',
    summary: 'GitHub does not report the PR mergeable and clean (a conflict, a branch rule, or a state GitHub is still computing)',
    fix: 'CONFLICTING: the lane merges the base into the branch, resolves, runs /ship and ready at the new head; UNKNOWN: rerun land in a minute; BLOCKED or BEHIND: meet the branch rule it names',
  },
  QUEUE_LAND_UNVERIFIED: {
    anchor: 'queue-land-unverified',
    summary: 'after the merge, the base branch tree is not the pin merged onto the merge commit\'s parent, so something besides the reviewed pin reached main',
    fix: 'compare the merge commit with the pin merged onto its parent, revert what does not belong to the PR, and report it to the Captain',
  },
  // gstack-restamp --release, gstack-release-stamp and the release route of land --pin (lib/release-stamp.ts): versions at release.
  RELEASE_STAMP_EMPTY: {
    anchor: 'release-stamp-empty',
    summary: 'the base holds no changelog fragment, so there is nothing to release and no release PR was opened',
    fix: 'nothing to do: the next release stamp folds the fragments the PRs landed since; the cut tags the current VERSION if it has no tag yet',
  },
  RELEASE_STAMP_INVALID: {
    anchor: 'release-stamp-invalid',
    summary: 'a release stamp ran off a clean checkout of the base, or a release/<version> head is more than the release stamp of its merge base',
    fix: 'open the release again with gstack-release-stamp open (it stamps a fresh checkout of origin/main); never edit a release/<version> branch by hand',
  },
  // gstack-pr-wait (lib/pr-wait.ts): the landing-path PR watcher's two terminal codes.
  PR_WAIT_BLOCKED: {
    anchor: 'pr-wait-blocked',
    summary: 'the --until condition cannot be met without action: a check failed, the branch conflicts with its base, the PR closed, ready is blocked by unresolved threads or a BEHIND branch, GitHub stayed unreachable, or --timeout passed',
    fix: 'act on the event lines above it (fix the check, update or rebase the branch, resolve the threads), push, and start gstack-pr-wait again; after a timeout, start again with a larger --timeout or --timeout 0',
  },
  PR_WAIT_REFUSED: {
    anchor: 'pr-wait-refused',
    summary: 'the watcher did not start, or a local error stopped it before a verdict',
    fix: 'pass a PR number or URL the current gh login can read (--repo owner/name when the checkout is not that repository), stop the watcher the line names before starting another for the same PR, or fix the named local error',
  },
  PREGATE_HEAD_POLICY_LOOSENS: {
    anchor: 'pregate-head-policy-loosens',
    summary: 'under --policy-from head, the branch’s .gstack/pregate.json removes, shrinks or loosens something the trusted policy declares; a head policy may only add test lanes',
    fix: 'keep every key of the trusted policy as it is and only add dependencies globs with tests (or tests on an existing glob); land any other change, a [] declaration included, in its own PR on the base branch first',
  },
  // The reviewer diff ceiling and the base policy's review_exclude_paths (lib/review-exclude.ts, GST-508).
  REVIEW_DIFF_TOO_LARGE: {
    anchor: 'review-diff-too-large',
    summary: 'one reviewer\'s diff is over the 2,000,000-byte review ceiling, so /ship stopped before writing a manifest or a brief instead of handing a reader more than it can read',
    fix: 'follow the fix the line prints for where the base policy stands: land the printed review_exclude_paths JSON on the base as its own PR, then bring the base into the branch and rerun once; or split the PR',
  },
  REVIEW_EXCLUDE_KEEP_TOO_LARGE: {
    anchor: 'review-exclude-keep-too-large',
    summary: 'a review_exclude_paths pattern keeps so many matched files in review that the command readers run to read them would pass 24,000 argument bytes, so gstack-review-plan stopped instead of silently dropping the pattern; the line names the pattern, the kept count, the reasons they are kept and the bytes',
    fix: 'when the kept files are published data (reason code on .patch, MANIFEST.sha256 or extension-less files), land a review_content_patterns entry over them beside the pattern on the base as its own PR, then bring the base into the branch and rerun once; otherwise narrow the pattern or split the PR',
  },
  VENDORED_MISMATCH: {
    anchor: 'vendored-mismatch',
    summary: 'a file a vendored manifest pins is not byte-for-byte the upstream file at the pinned commit (its git blob id differs), so it is not treated as vendored and stays in review',
    fix: 'restore the upstream bytes (rebuild it from the pinned commit), or remove the entry from the manifest so the edited file is reviewed as the repo\'s own code',
  },
  VENDORED_ABSENT_UPSTREAM: {
    anchor: 'vendored-absent-upstream',
    summary: 'the upstream path a vendored manifest entry names does not exist at the pinned commit',
    fix: 'correct the entry\'s upstream_prefix, file path or commit in the manifest so it names a file that exists upstream at that commit',
  },
  VENDORED_ABSENT_LOCAL: {
    anchor: 'vendored-absent-local',
    summary: 'a vendored manifest lists a file that is not in the commit being checked',
    fix: 'add the file, or remove its entry from the manifest (the repo\'s build writes both, so rebuild them together)',
  },
  VENDORED_MODE: {
    anchor: 'vendored-mode',
    summary: 'a vendored file is an executable, a symlink or a submodule, here or upstream; only plain files (mode 100644 on both sides) count as vendored',
    fix: 'clear the executable bit if the upstream file is a plain file, or remove the entry so the file is reviewed',
  },
  VENDORED_UNREACHABLE: {
    anchor: 'vendored-unreachable',
    summary: 'the pinned commit is not reachable from the upstream\'s default branch, its tags or a branch the base policy names for it (a fork\'s commit, a pull request head, a merge-queue branch or a force-pushed commit), so its files stay in review',
    fix: 'pin a commit on the upstream\'s default branch or a release tag; if the upstream ships from another branch, add it to that upstream\'s branches in review_vendored on the base branch as its own PR',
  },
  VENDORED_NOT_ALLOWLISTED: {
    anchor: 'vendored-not-allowlisted',
    summary: 'a vendored manifest pins files to an upstream that the base branch\'s review_vendored.upstreams does not list; a branch cannot trust a new upstream for itself',
    fix: 'add the upstream URL to review_vendored.upstreams on the base branch as its own PR, then bring the base into the branch and rerun',
  },
  VENDORED_FETCH_FAILED: {
    anchor: 'vendored-fetch-failed',
    summary: 'the upstream could not be fetched anonymously over https (deleted, renamed, private, redirected, or the network failed or timed out), so its files could not be checked and stay in review',
    fix: 'rerun once (a fetch has no side effects); if it fails again, check the URL opens without signing in and does not redirect, and update review_vendored.upstreams on the base if the repository moved',
  },
  VENDORED_MANIFEST_INVALID: {
    anchor: 'vendored-manifest-invalid',
    summary: 'a manifest the base policy lists is missing at the commit being checked or does not follow gstack-vendored/v1 (the line names the field), so none of its files count as vendored',
    fix: 'fix the field the line names (docs/vendored-code.md#the-manifest), usually by rerunning the repo\'s build that writes the manifest',
  },
  REVIEW_DIFF_UNREADABLE: {
    anchor: 'review-diff-unreadable',
    summary: 'git could not read a reviewer\'s diff (reason=timeout after timeout_ms, or reason=git-exit with git\'s exit code), so /ship stopped; the full stderr, with remote URLs redacted, is in the log= file',
    fix: 'timeout: rerun once unchanged, then split the PR or exclude its largest data folders on the base; git exit 128: git fetch origin <base>, then rerun once; anything else: stop and ask a person',
  },
  REVIEW_PLAN_STOPPED: {
    anchor: 'review-plan-stopped',
    summary: 'gstack-review-plan did not finish inside its limit (reason=timeout after timeout_ms, reason=signal when something killed it, reason=spawn when it could not start), so the review stopped before any reader ran: gstack-review-dispatch pass writes no manifest, render writes no brief, and a plan run by itself prints no plan',
    fix: 'rerun once unchanged; if reason=timeout again on a large repository (git ls-files | wc -l in the hundreds of thousands), set GSTACK_REVIEW_PLAN_TIMEOUT_MS (milliseconds, default 180000) to about twice the plan\'s time and rerun; otherwise report this line and the file count to your Captain; reason=signal: check the machine\'s free memory first',
  },
  REVIEW_EXCLUDE_REFERENCE: {
    anchor: 'review-exclude-reference',
    summary: 'informational: a kept code file names an excluded folder (a directory reference, not a full file path), so its files stay excluded and readers see that code without the files it reads',
    fix: 'nothing to do for the review; if that code\'s correctness depends on the excluded files, narrow review_exclude_paths on the base so they stay in the diff',
  },
  // The fetch rule's per-stage sweep (lib/review-sweep.ts, GST-1322).
  FETCH_VIOLATION: {
    anchor: 'fetch-violation',
    summary: 'a git repository with a network remote or a file of 100 MB or more appeared during one review stage, so every reader of that stage was quarantined and verify refuses until the stage reruns clean',
    fix: 'the pass reruns each slot once as <reader>#2 by itself; inspect each printed KEEP: path and leave it alone (nothing attributes it to a reader, so never delete it), then write a decision-trail row and tell your Captain',
  },
  FETCH_RERUN_BLOCKED: {
    anchor: 'fetch-rerun-blocked',
    summary: 'a path a stage\'s first attempt found still exists, so no stage of the pass, Step 11\'s voices included, dispatched a reader (one could read that path and sweep clean) and verify keeps refusing',
    fix: 'stop and report the printed path to your Captain; leave it alone (nothing attributes it to a reader, so never move or delete it yourself)',
  },
  FETCH_RERUN_SPENT: {
    anchor: 'fetch-rerun-spent',
    summary: 'the stage\'s one rerun fetched too, so the pass stopped with its readers quarantined, resuming it starts no later stage and returns no reader output, and verify refuses',
    fix: 'deal with the printed paths, find out why readers keep fetching, then start a fresh pass under a new --pass and --out; a third attempt is never automatic',
  },
  // GST-3053: gstack-ship-release push's last line, `PUSH: failed reason=<code>` (docs/unattended.md#push-line).
  PUSH_REFUSED: {
    anchor: 'push-refused',
    summary: 'gstack-ship-release push stopped before git push ran (a usage error, the wrong branch, the unanswered pre-push offer, open gate findings on a ready PR, sealed output, the secrets scan, the pre-push guards or a branch name that is not plain words), so nothing was pushed',
    fix: 'follow the STOP: line above it, then rerun gstack-ship-release push',
  },
  PUSH_REJECTED: {
    anchor: 'push-rejected',
    summary: 'git push was rejected: the remote branch has commits this branch lacks (non-fast-forward) or the remote refused the update, so nothing was pushed',
    fix: 'fetch and merge the remote under Step 3\'s conflict rules, run Steps 5-16 again, then rerun push; never force-push',
  },
  PUSH_GIT_FAILED: {
    anchor: 'push-git-failed',
    summary: 'git could not read the remote branch or git push failed for another reason (authentication, a pre-push hook or the network), so nothing was pushed',
    fix: 'repair the cause git printed in the STOP: line, repeat Step 16, then rerun push; never bypass a guard',
  },
  SPAWN_OUTPUT_INCOMPLETE: {
    anchor: 'spawn-output-incomplete',
    summary: 'a child process reported an error (ENOBUFS when its output passed maxBuffer) even though its exit status may be 0, so its output may be cut off and was not used',
    fix: 'rerun once; if the output really is that large (a huge diff or file list), narrow the range or paths, and report a repeat to the gstack maintainers with the command named here',
  },
} as const satisfies Record<string, ResultCode>;
